function isUzbekPhoneNumber(phoneNumber) {
  var regex = (998901234578);
  return regex.test(phoneNumber);
}

// var phoneNumber = "998901234567";
// if (isUzbekPhoneNumber(phoneNumber)) {
//   alert("Это узбекский номер телефона");
// } else {
//   alert("Это не узбекский номер телефона");
// }